"use client"

import React, { useEffect, useState } from 'react'
import Footer from "../components/footer/Footer";
import Header from "../components/header/Header";
import Link from 'next/link';
import Head from "next/head";

const term = () => {
    const [seo, setSeo] = useState();
    const canonicalUrl = `https://pinkspot.cc/privacypolicy/`;
    const ogImage = "https://pinkspot.cc/api/v1/uploads/4bcbbf50c52b57fe1dd3fb78c1b4f22c.png";

    const getseodetail = () => {
    fetch(`https://pinkspot.cc/api/v1/pages/getPageById/653251a1efe8c2f29fdce87d`)
      .then((res) => res.json())
      .then((data) => {
        setSeo(data?.data || {});
      })
      .catch((err) => console.error("SEO fetch error:", err));
  };
    useEffect(() => {
        getseodetail();
    }, []);
    return (
        <>
            <Head>
                {/* Canonical */}
                <link rel="canonical" href={canonicalUrl} />

                {/* Preload OG Image */}
                <link rel="preload" as="image" href={seo?.seoimageurl || ogImage} />

                {/* Basic SEO */}
                <title>{seo?.seotitle || "Privacy Policy - PinkSpot"}</title>
                <meta
                    name="description"
                    content={
                        seo?.seodescription || "Read PinkSpot's privacy policy to understand how we protect your data."
                    }
                />
                <meta
                    name="keywords"
                    content={
                        seo?.seokeyword || "privacy policy, PinkSpot privacy, data protection, terms"
                    }
                />
                <meta name="author" content="PINK SPOT" />

                {/* Open Graph */}
                <meta property="og:type" content="website" />
                <meta property="og:site_name" content="PinkSpot" />
                <meta property="og:title" content={seo?.seotitle || "Privacy Policy"} />
                <meta
                    property="og:description"
                    content={
                        seo?.seodescription || "Read PinkSpot's privacy policy to understand how we handle your personal data."
                    }
                />
                <meta property="og:image" content={seo?.seoimageurl || ogImage} />
                <meta property="og:url" content={canonicalUrl} />

                {/* Twitter */}
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content={seo?.seotitle || "Privacy Policy"} />
                <meta
                    name="twitter:description"
                    content={
                        seo?.seodescription ||"Read PinkSpot's privacy policy to understand how we handle your personal data."
                    }
                />
                <meta name="twitter:image" content={seo?.seoimageurl || ogImage} />

                {/* JSON-LD Schema */}
                <script
                    type="application/ld+json"
                    dangerouslySetInnerHTML={{
                        __html: JSON.stringify({
                            "@context": "https://schema.org",
                            "@type": "WebPage",
                            name: seo?.seotitle || "Privacy Policy",
                            description:
                                seo?.seodescription || "Read PinkSpot's privacy policy to understand how we handle your personal data.",
                            url: canonicalUrl,
                            publisher: {
                                "@type": "Organization",
                                name: "PinkSpot",
                                logo: {
                                    "@type": "ImageObject",
                                    url: ogImage,
                                },
                            },
                            image: seo?.seoimageurl || ogImage,
                        }),
                    }}
                />
            </Head>
            <div>
                <div className="container-fluid p-0">
                    <div className="terms-page">
                        <div className='home-banner'>
                            <Header className="position-absolute w-100" />
                            <div className="container">
                                <div className="banner-content text-start">
                                    <div className="">
                                        <h1 className="text-white">Privacy Policy</h1>
                                        <h3 className="text-white">
                                            Home <i className="fa-solid fa-angle-right text-white mx-2 fs-6"></i>Privacy Policy
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="py-5">
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <p className='text-responsive'>
                                            Your privacy is important to us. This Privacy Policy governs the manner in which Pink Spot Website www.pinkspot.cc  (“Pink Spot”, website”, “we” “us” or “our”) collects, uses, maintains and discloses Personally Identifiable. Information collected from its users (each a “user”,”member”, “you”, “your”, etc.).The purpose of this Privacy Policy is to assist you in understanding the purpose for which we collect, use, disclose and process the personal information you have provided to us or we may collect in accordance with the applicable data protection  law of Canada. We are devoted to protecting your privacy. Please read this privacy policy carefully. We are committed to take all attempts to protect the Personal Information that you disclose to us. By interacting or submitting any personal information or any other information to us for any events, it is deemed to be your full consent to permit us to collect, use and disclose such Personal information and other information, and disclose such Personal information to our authorized service providers and relevant third parties in accordance with this Privacy Policy.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>1. DEFINITIONS AND INTERPRETATION:</h4>
                                        <p className='text-responsive'>
                                            In this privacy policy, the following definitions are used:
                                            “Personal Data” or “Personal Information” is any information that relates to an identified or identifiable individual. Any information relating to You such as a name, an identification number, location data, online identifier or to one or more factors specific to the physical, physiological, genetic, mental, economic, cultural or social identity.
                                            “Cookies” are small files that are placed on Your computer, mobile device or any other device by a website, containing the details of Your browsing history on that website among its many uses.
                                            “Device” means any device that can access the Service such as a computer, a cellphone or a digital tablet.
                                            “Usage Data” refers to data collected automatically, either generated by the use of the Service or from the Service infrastructure itself (for example, the duration of a page visit).
                                            “Data Subject (or User)” Data Subject is any living individual who is using our website and its Service and is the subject of Personal Data.
                                            “Website” means www.pinkspot.cc and any sub-domains of this site unless expressly excluded by their own terms and conditions.
                                            In this privacy policy, unless the context requires a different interpretation the singular includes the plural and vice versa and a reference to a person includes firms, companies, government entities, trusts and partnerships;
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 2. HOW AND WHAT INFORMATION WE MAY COLLECT FROM YOU:</h4>
                                        <p className='text-responsive'>
                                            Personal information we or our affiliates may collect from you will depend on your use of our website. We may collect information from you when you visit, use or interact with our website. For the purpose of this Privacy Policy personally identifiable information-PII (the “ “Personal Data”) means any information relating to an identified or identifiable individual. We obtain Personal Information relating to you from various sources described below.
                                            <br />
                                            <br />
                                            <strong>A.	User-provided Information:</strong> We may collect and store personal or other information that you voluntarily supply to us while you when you register with us and set up an account to receive our services. We may collect personally information including but not limited to your Full Name, Email Address, Mailing Address i.e.: Country, State, City, Postcode, Phone Number, Date of Birth, Gender, ethnicity etc. and other necessary information through variety of ways including but not limited to, when you register an account with us, complete your profile ,contact us using our contact form, email, social media pages , sign up to our Newsletter, visit our website anonymously etc., We may also collect personal identification information if you voluntarily submit such information to us.
                                            <br />
                                            <br />
                                            <strong>B.	Payment Information:</strong> We may collect your payment information or financial information when you made any payment to us using your designated debit or credit card number or other. We don’t locally process any payments and we don’t collect any payment information by us or transferred to us either through our website or services. All payments will be handled through the secure gateway system, either through our website and/or otherwise. We may use third-party payment getaway including crypto currency payment system and any personal or financial information collected through such payment getaway will be conducted by the privacy statement of such payment getaway.
                                            <br />
                                            <br />
                                            <strong>C.	Social Media:</strong> We may collect your personal information if you interact with our social media pages/groups (i.e. Facebook.). We may collect embedded content from your social media profile and we may receive personal information about you from such social networking platform subject to the privacy policy of those social networking sites.
                                            <br />
                                            <br />
                                            <strong>D.	Information Collected via Technology:</strong> We may also collect and store information that is generated automatically as you navigate online through Our Website. When you visit or use our website we may collect we may collect technical information including but not limited to your Usage Information, your IP (Internet Protocol) address, location information, Log Data etc. This automatically collected information may include your IP address, web browser and/or device type etc. We also may use these technologies to collect information regarding your interaction with email messages, such as whether you opened, clicked on, or forwarded a message, to the extent permitted under applicable law.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 3. USE OF YOUR PERSONAL INFORMATION:</h4>
                                        <ul>
                                            <li className='text-responsive'>
                                                We and Our third-party service providers may use your personal information to provide our services to you smoothly and to meet your satisfaction to use our website and its services and to address your needs and concerns. For the following purposes, our third-party service providers and we may collect and use your personal information, including but not limited to
                                            </li>
                                            <li>To personify the user experience and to send your group invite or information for which you intend to provide your personal information; </li>
                                            <li>To maintain your interest with us; </li>
                                            <li>To Analyze and enhance our communications and strategies; and to improvement of our products / services</li>
                                            <li>Respond to your inquiries and to carry out marketing analysis and send you communications when we have your permission, or when permitted by law;</li>
                                            <li>To analyze and enhance our marketing communications and strategies (including identification of when emails we have sent to you have been received and read);</li>
                                            <li>To analyze trends and statistics regarding visitors' use of our app;</li>
                                            <li>To protect the security and safety of our users and Protect against and prevent fraud, unauthorized transactions, claims and other liabilities, and manage risk exposure, including by identifying potential hackers and other unauthorized users;</li>
                                            <li>Comply with all applicable legal requirements, industry standards and our policies, including reasonable necessity to comply with legal process and law enforcement instructions and orders’ </li>
                                            <li>Enforce this Privacy Policy. </li>
                                        </ul>
                                        <p className='text-responsive'>
                                            We do not share any of your personal information with any person or entity or any third party, other than as set out in this Privacy Policy. In no event, we do not sell trade, rent or otherwise transfer your any identifiable personal information to any third parties or non- affiliated companies for marketing purposes (including direct marketing purposes) without your permission.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 5. DISCLOSING OR SHARING YOUR PERSONAL INFORMATION:</h4>
                                        <p className='text-responsive'>
                                            We have sole discretion to take all reasonable steps to secure the information against unauthorized access or disclosure. Subject to this Privacy Policy and in accordance with any applicable law, this Personal Information may be disclosed. For the following circumstances we may share or disclose your information
                                        </p>
                                        <ul>
                                            <li>To any trusted third party, who assist us in operating our website, conducting our business, as long as those parties agree to keep this as confidential information</li>
                                            <li>To any of our group companies or affiliates, our customers or the public – for the purpose of protecting against harm to their rights, property or safety or to whom we transfer or may transfer our rights and duties</li>
                                            <li>To any relevant government regulators or authority or law enforcement agency to comply with any laws or rules and regulations imposed by any governmental authority; and</li>
                                            <li>To any other party, affiliates, entity or authority when we have believed in good faith that, disclosing any information is necessary to protect our rights or interest or property. </li>
                                            <li>To protect and defend the legal rights, liabilities, interests, property or safety of our Company, users, employees, or others to protect and defend our  rights,</li>
                                            <li>To whom you authorize us to disclose your personal Information</li>
                                            <li>To comply with applicable law or cooperate with law enforcement;</li>
                                        </ul>
                                        <p>We may also disclose or share your personal information in connection with a substantial corporate transaction, such as the sale of our business, a divestiture, merger, consolidation, or asset sale, or in the unlikely event of bankruptcy. In case of the change in ownership of our business through any viable means like a merger, an acquisition, takeover, or any similar event, your personal information may also be transferred to the new owner. In such scenarios, we will post a notice or otherwise notify you and collect your consent, as may be required by law, before the information is transferred and becomes subject to a different privacy policy.
                                            We may use your Data for the above purposes if we deem it necessary to do so for our legitimate interests. If you are not satisfied with this, you have the right to object in certain circumstances.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>6. CHILDREN’S PRIVACY: </h4>
                                        <p className='text-responsive'>
                                            We take children’s privacy seriously. Our website complies with the Personal Information Protection and Electronic Documents Act (PIPEDA). We do not knowingly collect Personal Information from children under the age of 18 or the age majority defines under your territory. If we become aware that a child under age of majority has provided us with Personal Information, we will delete such information from our website or server.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>7. COOKIES POLICY: </h4>
                                        <p className='text-responsive'>
                                            Our Website may use “cookies” to enhance User experience. User’s web browser places cookies on their hard drive for record-keeping purposes and sometimes to track information about them. Cookies are small files that your web browser places on your hard drive for record-keeping purposes. By showing how and when visitors use Our Website, cookies help us deliver advertisements, identifying how many unique users visit us, and tracking user trends and patterns. They also prevent you from having to re-enter your preferences on certain areas of Our Website where you may have entered preference information before. Our Website also may use web beacons (single-pixel graphic files also known as “transparent GIFs”) to access cookies and to count users who visit Our Website or open HTML-formatted email messages. Cookies can compile information about your browsing habits and can also enhance your browsing experience. We use cookies for the following purposes:
                                        </p>
                                        <ul>
                                            <li>To understand your browsing habits of our website;</li>
                                            <li>To improve your user experience of our website;</li>
                                            <li>To remember your preferences;</li>
                                            <li>To help us understand how this website is performing;</li>
                                            <li>To understand the number of visitors to Our Websites and the pages visited; and</li>
                                            <li>To enable this website to function properly</li>
                                        </ul>
                                        <p>Personal Information (if any) that we collect from you through “cookies” may be transferred  to our third party service providers, whether located in Canada or elsewhere, for one or more of the Purposes, for managing and/or administering our website, or for the purpose of data hosting/storage/backup. Your use of our website constitutes consent by you to our use of cookies and to the matters set out herein. You can instruct your browser, by editing its options, to stop accepting cookies or to prompt you before accepting a cookie from the websites you visit. Please note that, by not accepting cookies, you might not be able to use all functionality of this site or its services.</p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>8. ADVERTISING AND ANALYTICS: </h4>
                                        <p className='text-responsive'>
                                            We may use third-party advertising platform including but not limited to Google ads, Facebook Ads, Google Analytics and Facebook's ad tracking feature, etc. to promote our services and Services. We may also use remarketing pixels through Google and Facebook. We do not share personal information that directly identifies you with third-party advertisers for their direct marketing purposes. We may use Google Analytics, which may uses “cookies”. The information generated by the “cookies” about your use of the website (including your IP address) will be transmitted to and stored by Google on servers in the United States. You can refuse the use of Google Analytics by clicking on Opt-Out.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 9. AUTO RESPONDERS AND MARKETING OPT-OUTS:</h4>
                                        <p className='text-responsive'>
                                            We may use auto responders to communicate with you by e-mail. To protect your privacy, we use a verified opt-in system for such communications and you can opt-out of receiving such emails and other messages from of such communications using the links contained in each auto responder message or by following the instructions in those emails. If you have difficulties opting out, you may contact us by sending an email support@pinkspot.cc
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>10. SECURITY OF YOUR INFORMATION:  </h4>
                                        <p className='text-responsive'>
                                            We committed to protect or safeguard the information we collect from you. We are following commonly accepted industry standards to protect the personal information submitted to us including using SSL CERTIFICATE security system for ensuring and protect the confidentiality of your personally identifiable information. However, no method of transmission over the Internet or method of electronic storages is 100% safe and secure. . You should carefully consider which Data you choose to share with us or make available via the Website. You should take care to use suitably strong passwords that others cannot guess, that are kept safe by you, and that are not re-used elsewhere. If you believe your password has been compromised, you should change it immediately.  Therefore, we are not in the actual position to guarantee the absolute security of your information. If you have any questions about security on our website, you can submit us an email support@pinkspot.cc .We may take all reasonable steps and may allow third parties and who assist us to adopt proper security measure to safeguard your personal information.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4>11. GOVERNING LAW AND JURISDICTION:  </h4>
                                        <p className='text-responsive'>
                                            This privacy statement has been prepared and will be governed in accordance with the The Personal Information Protection and Electronic Documents Act (PIPEDA) of Canada and other applicable Canadian and international data protection law. We and each user may submit to the exclusive jurisdiction of the local territory of the users.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 12. INTERNATIONAL DATA TRANSFER:</h4>
                                        <p className='text-responsive'>
                                            Our website is hosted in the Canada and is governed by the law of the Canada. We do not represent or warrant that our website or any part thereof, is appropriate or available for use in any particular geographic location. If you choose to access our website, you do so on your own initiative and at your own risk, and are responsible for complying with all local laws, rules, and regulations applicable in your jurisdiction. If you are visiting the Website from outside the Canada, please be aware that your information will be transferred to, stored and processed in the Canada By using the website and its service you hereby also consent to your information being transferred to our contractors, service providers, facilities and other third parties we use to support our business and which may reside outside of the Canada and those countries may have different privacy laws In these circumstances, the governments, courts, law enforcement, or regulatory agencies of that country may be able to obtain access to your Data through the laws of the foreign country. Whenever we engage a service provider, we require that its privacy and security standards adhere to this policy and applicable Canadian privacy legislation
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h4> 13. CHOICES YOU HAVE ABOUT YOUR INFORMATION:</h4>
                                        <p className='text-responsive'>
                                            You may, of course, decline to submit information to us, in which case you may not be able to use our website and its services. You may also control the types of notifications and communications we send, limit the information shared within our website about you, and otherwise amend certain privacy settings.
                                            You have certain rights under The Personal Information Protection and Electronic Documents Act (PIPEDA) including the right to request a copy of the personal information we hold about you if you request it from us in writing. You can exercise the following rights in accordance with this privacy policy
                                        </p>
                                        <ol type="a">
                                            <li>Right to access: the right to request copies of your personal information from us;</li>
                                            <li>Right to correct: the right to have your personal information rectified if it is inaccurate or incomplete;</li>
                                            <li>Right to erase: the right to request that we delete or remove your personal information from our systems;</li>
                                            <li>Right to withdraw:  the right to withdraw consent where they have previously given their consent to the processing of their Personal information.</li>
                                            <li>Right to restrict our use of your information: the right to ‘block’ us from using your personal information or limit the way in which we can use it;</li>
                                            <li>Right to data portability: the right to request that we move, copy or transfer your personal information;</li>
                                            <li>Verify and seek rectification: the right to verify the accuracy of their Data and ask for it to be updated or corrected;</li>
                                            <li>Right to object: the right to object to our use of your personal information including where we use it for our legitimate interests or where we use your personal information to carry out profiling to inform our market research and customer demographics.</li>
                                            <li>Lodge a complaint: the right to bring a claim before their competent data protection authority.</li>
                                            <li>Right to Nondiscrimination: We do not discriminate against users who exercise their privacy rights. You are entitled to exercise the rights described above free from discrimination prohibited by the PIPEDA.</li>
                                        </ol>
                                        <p>
                                            You may exercise your right to access, update, amend or delete your Personal Information that has been previously provided to us by contacting us at support@pinkspot.cc  . We will try to comply with your request to update your Personal Information as soon as reasonably practicable. We are not responsible for changing information from the databases of third parties with whom we have already shared your Personal Information. Please note that we may ask you to verify your identity before responding to such requests. If you make a request, we will try our best to respond to you as soon as possible.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3> 14. THIRD-PARTY LINK POLICY: </h3>
                                        <p className='text-responsive'>
                                            Website may, from time to time, provide links to other websites.  We have no control over such website and by clicking on such links it may redirected you to third party website or apps which  may collect information about you when you use their services or communicate with them. We are not responsible for the privacy practices of other businesses and any use of such third-parties or any submission of information to them will be subject to the applicable privacy policy of those third-parties. You are advised to read the privacy policy or statement of other websites prior to using them.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3> 15. DURATION OF HOLDING YOUR PERSONAL INFORMATION:</h3>
                                        <p className='text-responsive'>
                                            Unless a longer retention period is required or permitted by law, we will only hold your personal information on our systems for the period necessary to fulfill the purposes outlined in this Privacy Policy or until you request, it is deleted. Even if we delete your personal information, it may persist on backup or archival media for legal, tax or regulatory purposes
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3> 16. YOUR CONSENT:</h3>
                                        <p className='text-responsive'>
                                            By using our website or any interaction with our services, you provide your consent to us to collect and process your information in accordance with this privacy policy. Wherever possible, we will attempt to obtain your explicit consent to collect and process your information. If you have given us explicit permission to do so, we may share your personal information to selected partners whom we believe may provide services you would find useful. Sometimes you may give implicit consent, such as when you send us a message through our support or by e-mail to which you would reasonably expect us to reply. Without your consent to use of your personal information for a specific purpose, we do not use your information in any way that would identify you personally. You may withdraw your consent at any time by contacting us at support@pickspot.cc
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3>17. TRACKING PRIVACY POLICY:</h3>
                                        <p className='text-responsive'>
                                            We don’t track you personally or your personal information for any other purpose. Only we may track your use of our website in general, so that we can make it better. We are monitoring traffic, usage activity, site performance, and we use general analytic tools so that we can improve your experience. We never sell or share your personally identifiable information unless required to do so by law.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3>18. CHANGES TO THIS PRIVACY POLICY:</h3>
                                        <p className='text-responsive'>
                                            We have sole discretion to modify or update or amend this privacy policy at any time without any prior notice. Changes or modifications will take effect immediately upon posting on our website. If we make any material changes to this policy, we will notify you here that it has been updated so that you can be aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3>19. YOUR ACCEPTANCE TO THIS POLICY:</h3>
                                        <p className='text-responsive'>
                                            By using this Platform, you signify your acceptance of this Privacy Policy. If you do not agree to this policy, please do not use our service. Your continued use of Our Website following the posting of changes to this policy will be deemed your acceptance of those changes.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className='container mt-3'>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <h3>20. CONTACT US:</h3>
                                        <p className='text-responsive'>
                                            If you have any question about this Privacy Policy or would like to access or modify your personal identifiable information, please contact us support@pinkspot.cc
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <Footer />
                </div>
            </div>
        </>
    )
}

export default term